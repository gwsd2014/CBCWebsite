package generator;

public enum ComponentTypes {
	Problem, Class, Function, Logic, Loop, Conditional, Arithmetic, Line, None;
}
