package generator;

/**
 * This class is the queue of problems for each student
 * @author Michael
 */
public class ProblemQueue {

	/**
	 * Add a problem to the queue
	 * @param problem
	 */
	public void enqueue(ProblemComponent problem){
		
	}
	
	/**
	 * Remove a problem from the head of the queue
	 * @return
	 */
	public ProblemComponent dequeue(){
		return null;
	}
	
}
