package server;

/**
 * This class accepts new connections, and creates new thread for each user
 * @author Michael
 *
 */
public class Server {
	
	/**
	 * Run indefinitely, accept connections, create new Control thread for each user 
	 */
	public void run(){
		
	}
	
}
