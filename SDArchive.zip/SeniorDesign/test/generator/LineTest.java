package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class LineTest {

	@Test
	public void testDeclareVariable() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddition() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetParent() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetParent() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVarValMap() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTokenList() {
		fail("Not yet implemented");
	}

}
