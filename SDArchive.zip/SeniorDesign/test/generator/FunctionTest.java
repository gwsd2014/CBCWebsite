package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class FunctionTest {

	@Test
	public void testDeclareVariables() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateLogics() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetParent() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetParent() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetChildLogics() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetChildLines() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTestVariable() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVariables() {
		fail("Not yet implemented");
	}

}
