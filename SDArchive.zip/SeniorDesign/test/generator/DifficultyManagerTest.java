package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class DifficultyManagerTest {

	@Test
	public void testAdjustDifficulty() {
		fail("Not yet implemented");
	}

}
