package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ControlTest {

	@Test
	public void testFillQueue() {
		fail("Not yet implemented");
	}

}
