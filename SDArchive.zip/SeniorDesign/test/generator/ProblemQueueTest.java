package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProblemQueueTest {

	@Test
	public void testEnqueue() {
		fail("Not yet implemented");
	}

	@Test
	public void testDequeue() {
		fail("Not yet implemented");
	}

}
