package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProblemTest {

	@Test
	public void testGetTestVariable() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCorrectAnswer() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetIncorrect1() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetIncorrect2() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetIncorrect3() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetChildren() {
		fail("Not yet implemented");
	}

}
