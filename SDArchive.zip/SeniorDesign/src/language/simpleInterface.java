package language;

public interface simpleInterface {

	public int Main();
	
}
