package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConverterTest {

	@Test
	public void testConvertProblem() {
		fail("Not yet implemented");
	}

	@Test
	public void testConvertClass() {
		fail("Not yet implemented");
	}

	@Test
	public void testConvertFunction() {
		fail("Not yet implemented");
	}

	@Test
	public void testConvertLogic() {
		fail("Not yet implemented");
	}

	@Test
	public void testConvertLine() {
		fail("Not yet implemented");
	}

}
