package generator;

public enum ProblemType {
	INVALID, MULTI_CHOICE, FILL_BLANK, OPEN_RESPONSE
}
