package generator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ClassTest {

	@Test
	public void testCreateFunctions() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetParent() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetParent() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetChildren() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVariables() {
		fail("Not yet implemented");
	}

}
